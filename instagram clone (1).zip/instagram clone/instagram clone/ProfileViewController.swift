//
//  ProfileViewController.swift
//  instagram clone
//
//  Created by agile14 on 23/07/22.
//

import UIKit

class ProfileViewController: UIViewController {
    @IBOutlet weak var profileTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        profileTableView.dataSource = self
        profileTableView.delegate = self
        
        profileTableView.register(UINib(nibName: "topCell", bundle: nil), forCellReuseIdentifier: "topCell")
        profileTableView.register(UINib(nibName: "secondProfileCell", bundle: nil), forCellReuseIdentifier: "secondProfileCell")
        profileTableView.register(UINib(nibName: "StoriesCell", bundle: nil), forCellReuseIdentifier: "storyCell")
    }
    

}

extension ProfileViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = indexPath.row
        if row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "topCell", for: indexPath) as! topCell
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "secondProfileCell", for: indexPath)
            return cell
        }

    }
    
    
    
}

extension ProfileViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let row = indexPath.row
        if row == 0 {
            return 60
        } else if row == 1 {
            return 200
        } else {
            return 80
        }
        
    }
}
