//
//  searchCell.swift
//  instagram clone
//
//  Created by agile14 on 23/07/22.
//

import UIKit

class searchCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
