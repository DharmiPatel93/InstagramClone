//
//  homeTableViewCell.swift
//  instagram clone
//
//  Created by agile14 on 21/07/22.
//

import UIKit

class homeTableViewCell: UITableViewCell {

    @IBOutlet weak var storyCollecView: UICollectionView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        storyCollecView.dataSource = self
        storyCollecView.delegate = self
    
        storyCollecView.register(UINib(nibName: "StoriesCell", bundle: nil), forCellWithReuseIdentifier: "storyCell")
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

extension homeTableViewCell: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "storyCell", for: indexPath) as! StoriesCell
        
        return cell
    }
    
    
}

extension homeTableViewCell: UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: collectionView.frame.height, height: collectionView.frame.height)
    }
    
}

