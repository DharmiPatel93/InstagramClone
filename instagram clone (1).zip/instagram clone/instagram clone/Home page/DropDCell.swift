//
//  DropDownCell.swift
//  instagram clone
//
//  Created by agile14 on 23/07/22.
//

import UIKit

class DropDCell: UITableViewCell {

   
//    @IBOutlet weak var lbl: UILabel!
//    @IBOutlet weak var DropDownImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
//        let dict = ["post": "square.grid.3x3.fill.square"]
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
