//
//  StoriesCell.swift
//  instagram clone
//
//  Created by agile14 on 21/07/22.
//

import UIKit

class StoriesCell: UICollectionViewCell {
    
    @IBOutlet weak var storyImg: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
            
        storyImg.layer.cornerRadius = 28
    }

}
