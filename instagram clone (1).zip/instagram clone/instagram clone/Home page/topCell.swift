//
//  topCell.swift
//  instagram clone
//
//  Created by agile14 on 23/07/22.
//

import UIKit
import DropDown

class topCell: UITableViewCell {

    var dropDown = DropDown()
    
    @IBOutlet weak var plusButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        dropDown.anchorView = plusButton
        dropDown.width = 150
//        dropDown.cellNib = UINib(nibName: "DropDCell", bundle: nil)
        dropDown.dataSource = ["Post", "Story", "Reel", "Live"]

        }
    
    
    @IBAction func plusAction(_ sender: UIButton) {
        dropDown.show()
    }
    
    }

//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
//    }
    
    
