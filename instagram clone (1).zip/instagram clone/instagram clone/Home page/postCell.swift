//
//  postCell.swift
//  instagram clone
//
//  Created by agile14 on 23/07/22.
//

import UIKit

class postCell: UITableViewCell {

    @IBOutlet weak var profileImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        profileImage.layer.cornerRadius = 20
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    var closer:((_ act: UIActivityViewController) -> Void)!
    @IBAction func moreOptionsAction(_ sender: UIButton) {
        
        
        
//        if let url = URL(string: whatsappUrl), UIApplication.shared.canOpenURL(url) {
//
//            UIApplication.shared.open(url)
//        }
        let whatsappUrl = "https://api.whatsapp.com/send?phone="

        let activity = UIActivityViewController(activityItems: [whatsappUrl], applicationActivities: nil)
        
        closer(activity)
        
        
    }
    
    
}
