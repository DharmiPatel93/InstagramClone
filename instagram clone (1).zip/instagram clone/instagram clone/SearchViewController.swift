//
//  SearchViewController.swift
//  instagram clone
//
//  Created by agile14 on 23/07/22.
//

import UIKit

class SearchViewController: UIViewController {

    @IBOutlet weak var CollView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        CollView.dataSource = self
        CollView.delegate = self
        CollView.register(UINib(nibName: "searchCell", bundle: nil), forCellWithReuseIdentifier: "searchCell")
        CollView.collectionViewLayout = UICollectionViewFlowLayout()
    }
        
    

}

extension SearchViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 72
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "searchCell", for: indexPath)
        
        return cell
    }
    
}

extension SearchViewController: UICollectionViewDelegateFlowLayout, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: CollView.frame.width / 3.2, height: CollView.frame.width / 3.2)
    }
    
}
