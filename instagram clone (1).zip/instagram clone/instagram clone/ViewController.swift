//
//  ViewController.swift
//  instagram clone
//
//  Created by agile14 on 21/07/22.
//

import UIKit
import DropDown

class ViewController: UIViewController {

    var dropDown = DropDown()
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        tableView.register(UINib(nibName: "topCell", bundle: nil), forCellReuseIdentifier: "topCell")
        tableView.register(UINib(nibName: "homeTableViewCell", bundle: nil), forCellReuseIdentifier: "tableStory")
        tableView.register(UINib(nibName: "postCell", bundle: nil), forCellReuseIdentifier: "postCell")
    }


}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let row = indexPath.row
        
        if row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "topCell", for: indexPath) as! topCell
            
            return cell
        } else if row == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "tableStory", for: indexPath) as! homeTableViewCell
            
            return cell
        } else {
            let postCell = tableView.dequeueReusableCell(withIdentifier: "postCell", for: indexPath) as! postCell
            
            postCell.closer = { act in
                self.present(act, animated: true)
            }
            return postCell
        }
        
    }
    
    
}

extension ViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 60
        }
        else if indexPath.row == 1{
            return 80
        }
        else {
            return 320
        }
        
    }
}
